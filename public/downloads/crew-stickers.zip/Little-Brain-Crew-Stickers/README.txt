Little Brain Crew stickers

12 crew stickers, 512 x 512 px.
png/   for Telegram, iMessage, or to send as a picture anywhere.
webp/  for WhatsApp sticker apps (Sticker Maker and similar).

Free for your family chats. Please don't sell them.
littlebraincrew.com · hello@littlebraincrew.com
